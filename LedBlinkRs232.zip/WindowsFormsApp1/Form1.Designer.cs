﻿
using System;

namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tümLed = new System.Windows.Forms.Button();
            this.led3 = new System.Windows.Forms.Button();
            this.led2 = new System.Windows.Forms.Button();
            this.led1 = new System.Windows.Forms.Button();
            this.bildirimMesaji = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.baglan = new System.Windows.Forms.Button();
            this.comPort = new System.Windows.Forms.ComboBox();
            this.baudRate = new System.Windows.Forms.ComboBox();
            this.parity = new System.Windows.Forms.ComboBox();
            this.dataBits = new System.Windows.Forms.ComboBox();
            this.stopBit = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.tümLed);
            this.groupBox2.Controls.Add(this.led3);
            this.groupBox2.Controls.Add(this.led2);
            this.groupBox2.Controls.Add(this.led1);
            this.groupBox2.Location = new System.Drawing.Point(160, 10);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(190, 223);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Led Kontrolü";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(109, 135);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Tüm Ledler";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 135);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Led -3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(109, 46);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Led -2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 46);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Led-1";
            // 
            // tümLed
            // 
            this.tümLed.Location = new System.Drawing.Point(111, 154);
            this.tümLed.Margin = new System.Windows.Forms.Padding(2);
            this.tümLed.Name = "tümLed";
            this.tümLed.Size = new System.Drawing.Size(56, 57);
            this.tümLed.TabIndex = 3;
            this.tümLed.Text = "Işıkları Yak";
            this.tümLed.UseVisualStyleBackColor = true;
            this.tümLed.Click += new System.EventHandler(this.led4_Click);
            // 
            // led3
            // 
            this.led3.Location = new System.Drawing.Point(26, 154);
            this.led3.Margin = new System.Windows.Forms.Padding(2);
            this.led3.Name = "led3";
            this.led3.Size = new System.Drawing.Size(56, 57);
            this.led3.TabIndex = 2;
            this.led3.Text = "Işığı Yak";
            this.led3.UseVisualStyleBackColor = true;
            this.led3.Click += new System.EventHandler(this.led3_Click);
            // 
            // led2
            // 
            this.led2.Location = new System.Drawing.Point(111, 62);
            this.led2.Margin = new System.Windows.Forms.Padding(2);
            this.led2.Name = "led2";
            this.led2.Size = new System.Drawing.Size(56, 57);
            this.led2.TabIndex = 1;
            this.led2.Text = "Işığı Yak";
            this.led2.UseVisualStyleBackColor = true;
            this.led2.Click += new System.EventHandler(this.led2_Click);
            // 
            // led1
            // 
            this.led1.Location = new System.Drawing.Point(26, 62);
            this.led1.Margin = new System.Windows.Forms.Padding(2);
            this.led1.Name = "led1";
            this.led1.Size = new System.Drawing.Size(56, 57);
            this.led1.TabIndex = 0;
            this.led1.Text = "Işığı Yak";
            this.led1.UseVisualStyleBackColor = true;
            this.led1.Click += new System.EventHandler(this.led1_Click_1);
            // 
            // bildirimMesaji
            // 
            this.bildirimMesaji.Location = new System.Drawing.Point(9, 238);
            this.bildirimMesaji.Margin = new System.Windows.Forms.Padding(2);
            this.bildirimMesaji.Name = "bildirimMesaji";
            this.bildirimMesaji.Size = new System.Drawing.Size(326, 20);
            this.bildirimMesaji.TabIndex = 2;
            this.bildirimMesaji.Text = "Bağlantı ayarlarını yapınız..";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 65);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Com Port";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 85);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Baud Rate";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 108);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Parity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 131);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "DataBits";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 154);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "StopBit";
            // 
            // baglan
            // 
            this.baglan.Location = new System.Drawing.Point(65, 176);
            this.baglan.Margin = new System.Windows.Forms.Padding(2);
            this.baglan.Name = "baglan";
            this.baglan.Size = new System.Drawing.Size(56, 41);
            this.baglan.TabIndex = 10;
            this.baglan.Text = "Bağlan";
            this.baglan.UseVisualStyleBackColor = true;
            this.baglan.Click += new System.EventHandler(this.baglan_Click);
            // 
            // comPort
            // 
            this.comPort.FormattingEnabled = true;
            this.comPort.Location = new System.Drawing.Point(65, 58);
            this.comPort.Margin = new System.Windows.Forms.Padding(2);
            this.comPort.Name = "comPort";
            this.comPort.Size = new System.Drawing.Size(66, 21);
            this.comPort.TabIndex = 11;
            // 
            // baudRate
            // 
            this.baudRate.FormattingEnabled = true;
            this.baudRate.Location = new System.Drawing.Point(65, 80);
            this.baudRate.Margin = new System.Windows.Forms.Padding(2);
            this.baudRate.Name = "baudRate";
            this.baudRate.Size = new System.Drawing.Size(66, 21);
            this.baudRate.TabIndex = 12;
            // 
            // parity
            // 
            this.parity.FormattingEnabled = true;
            this.parity.Location = new System.Drawing.Point(65, 102);
            this.parity.Margin = new System.Windows.Forms.Padding(2);
            this.parity.Name = "parity";
            this.parity.Size = new System.Drawing.Size(66, 21);
            this.parity.TabIndex = 13;
            // 
            // dataBits
            // 
            this.dataBits.FormattingEnabled = true;
            this.dataBits.Location = new System.Drawing.Point(65, 126);
            this.dataBits.Margin = new System.Windows.Forms.Padding(2);
            this.dataBits.Name = "dataBits";
            this.dataBits.Size = new System.Drawing.Size(66, 21);
            this.dataBits.TabIndex = 14;
            // 
            // stopBit
            // 
            this.stopBit.FormattingEnabled = true;
            this.stopBit.Location = new System.Drawing.Point(65, 150);
            this.stopBit.Margin = new System.Windows.Forms.Padding(2);
            this.stopBit.Name = "stopBit";
            this.stopBit.Size = new System.Drawing.Size(66, 21);
            this.stopBit.TabIndex = 15;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.stopBit);
            this.groupBox1.Controls.Add(this.dataBits);
            this.groupBox1.Controls.Add(this.parity);
            this.groupBox1.Controls.Add(this.baudRate);
            this.groupBox1.Controls.Add(this.comPort);
            this.groupBox1.Controls.Add(this.baglan);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(9, 10);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(147, 223);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bağlantı Ayarları";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 268);
            this.Controls.Add(this.bildirimMesaji);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button led1;
        private System.Windows.Forms.Button tümLed;
        private System.Windows.Forms.Button led3;
        private System.Windows.Forms.Button led2;
        private System.Windows.Forms.TextBox bildirimMesaji;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private EventHandler groupBox1_Enter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button baglan;
        private System.Windows.Forms.ComboBox comPort;
        private System.Windows.Forms.ComboBox baudRate;
        private System.Windows.Forms.ComboBox parity;
        private System.Windows.Forms.ComboBox dataBits;
        private System.Windows.Forms.ComboBox stopBit;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

