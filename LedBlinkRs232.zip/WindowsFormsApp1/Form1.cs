﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.Collections;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int[] baglantiHizlari = new int[] { 110, 300, 600, 1200, 2400, 4800, 9600, 19200 };
        int[] veriBitleri = new int[] { 5, 6, 7, 8, };


        private void Form1_Load(object sender, EventArgs e)
        {
            ArrayList baudRateArray = new ArrayList(baglantiHizlari);
            ArrayList dataBitsArray = new ArrayList(veriBitleri);
            
            if(serialPort1.IsOpen)
            {
                serialPort1.Close();
            }
            bildirimMesaji.Text = "Bağlantı ayarlarını yapınız...";
            string[] comPorts = SerialPort.GetPortNames();

            foreach(string port in comPorts)
            {
                comPort.Items.Add(port);

            }

            parity.Items.AddRange(Enum.GetNames(typeof(System.IO.Ports.Parity)));
            stopBit.Items.AddRange(Enum.GetNames(typeof(System.IO.Ports.StopBits)));

            baudRate.Items.AddRange(baudRateArray.ToArray());
            dataBits.Items.AddRange(dataBitsArray.ToArray());

        }



        private void baglan_Click(object sender, EventArgs e)
        {
            if (baglan.Text == "Bağlan") 
            {
                try
                {
                    serialPort1.PortName = comPort.SelectedItem.ToString();
                    serialPort1.BaudRate = int.Parse(baudRate.SelectedItem.ToString());
                    serialPort1.Parity = (System.IO.Ports.Parity)Enum.Parse(typeof(System.IO.Ports.Parity), parity.SelectedItem.ToString());

                    serialPort1.Open();
                    baglan.Text = "Kopar";
                    bildirimMesaji.Text = comPort.SelectedItem.ToString() + "bağlandı.";
                    foreach(Control kontrol in groupBox1.Controls)
                    {
                        if(kontrol is ComboBox)
                        {
                            kontrol.Enabled = false;
                        }
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
            else
            {
                serialPort1.Close();
                baglan.Text = "Bağlan";
                foreach(Control kontrol in groupBox1.Controls)
                {
                    if(kontrol is ComboBox)
                    {
                        kontrol.Enabled = true;

                    }
                }
                bildirimMesaji.Text = "Bağlantı ayarlarını yapınız...";

            }
                
        }
        int led1Toggle = 0;
        int led2Toggle = 0;
        int led3Toggle = 0;
        byte[] data = { 0 };

        ///<summary>
        ///
        /// </summary>
        /// <param name="sender">Butonun adını(name) giriniz.</param>
        /// <param name="renk">Arkaplan rengi string olarak giriniz</param>
        /// <param name="veri">Gönderilecek veriyi byte olarak giriniz.</param>
        public void butonSecme(object sender,string renk,byte veri)
        {
            Button buton = sender as Button;
            data[0] = veri;
            if(serialPort1.IsOpen)
            {
                if (buton.Text == "Işığı Yak")
                {
                    buton.BackColor = Color.FromName(renk);
                    buton.Text = "Işığı Söndür";
                    serialPort1.Write(data, 0, 1);

                }
                else
                {
                    buton.BackColor = Color.FromName(renk);
                    buton.Text = "Işığı yak..";
                    serialPort1.Write(data, 0, 1);

                }
               
                        
                        
             }
            else
            {
                MessageBox.Show("Bağlantı açık değil", "uyarı", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        ///<summary>
        ///
        /// </summary>
        /// <param name="sender">Butonun adını(name) giriniz  </param>
        /// <param name="renk">Arkaplan rengi string olarak giriniz.</param>
        public void butonSecme(object sender,string renk)
        {
            Button buton = sender as Button;
            if(tümLed.BackColor==Color.Cyan)
            {
                buton.BackColor = Color.FromName(renk);

            }
            else
            {
                buton.BackColor = Color.FromName(renk);
            }
        }

        public void tümLedKontrol()
        {
            if (led1Toggle == 1 && led2Toggle == 1 && led3Toggle == 1)
            {
                tümLed.Text = "Işıkları Söndür";
                tümLed.BackColor = Color.FromName("Cyan");
            }
            else if (led1Toggle==0&& led2Toggle==0 &&led3Toggle==0)
            {
                tümLed.Text = "Işıkları Yak";
                tümLed.BackColor = Color.FromName("Control");


            }
            else { }



        }

        private void led1_Click_1(object sender, EventArgs e)
        {
            led1Toggle++;
            if(led1Toggle==1)
            {
                butonSecme(led1, "Blue", 10);
                tümLedKontrol();

            }
            else
            {
                butonSecme(led1, "Control", 11);
                led1Toggle = 0;
                tümLedKontrol();

            }
        }

        private void led2_Click(object sender, EventArgs e)
        {
            led2Toggle++;
            if(led2Toggle==1)
            {
                butonSecme(led2, "Red", 20);
                tümLedKontrol();

            }
            else
            {
                butonSecme(led2, "Control", 22);
                led2Toggle = 0;
                tümLedKontrol();

            }
        }

        private void led3_Click(object sender, EventArgs e)
        {
            led3Toggle++;
                if(led3Toggle==1)
                {
                butonSecme(led3, "Green", 30);
                tümLedKontrol();

                }
                else
                {
                butonSecme(led3, "Control", 33);
                led3Toggle = 0;
                tümLedKontrol();

                }
        }

        private void led4_Click(object sender, EventArgs e)
        {
            if(serialPort1.IsOpen)
            {
                if(tümLed.Text=="Işıkları Yak")
                {
                    data[0] = 40;
                    tümLed.BackColor = Color.Cyan;
                    tümLed.Text = "Işıkları Söndür";
                    serialPort1.Write(data, 0, 1);
                    led1Toggle++;
                    led2Toggle++;
                    led3Toggle++;
                    butonSecme(led1, "Blue");
                    butonSecme(led2, "Red");
                    butonSecme(led3, "Green");

                }
                else
                {
                    data[0] = 44;
                    tümLed.BackColor = Color.FromName("Control");
                    tümLed.Text = "Işıkları Yak";
                    serialPort1.Write(data, 0, 1);
                    butonSecme(led1, "Control");
                    butonSecme(led2, "Control");
                    butonSecme(led3, "Control");
                    led1Toggle = 0;
                    led2Toggle = 0;
                    led3Toggle =0;


                }
            }
            else
            {
                MessageBox.Show("Bağlantı Açık Değil", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void Form1_FormClosed(object sender,FormClosedEventArgs e)
        {
            Application.Exit();
        }

       
    }
}
